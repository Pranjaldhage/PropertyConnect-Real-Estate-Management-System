﻿namespace EnquiryService.Models
{
    public enum EnquiryStatus
    {
        NEW,
        APPROVED,
        REJECTED
    }
}
